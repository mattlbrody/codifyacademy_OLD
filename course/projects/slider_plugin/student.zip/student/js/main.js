// blank function to stop any other jquery interacting with our plugin
(function($) {
	// declares our function name & creates the object which we can later call in html
    $.fn.codifySlider = function() {

        // Set general variables
        // ====================================================================
        var totalWidth = 0;

        // Total width is calculated by looping through each gallery item and
        // adding up each width and storing that in `totalWidth` - tells jquery the box model width
        $("span").each(function(){
            totalWidth = totalWidth + $(this).outerWidth(true);
        });

        // The maxScrollPosition is the furthest point the items should
        // ever scroll to. We always want the viewport to be full of images. - everything except for the margins
        var maxScrollPosition = totalWidth - $(".wrapper").outerWidth();

        // This is the core function that animates to the target item - passing the parameter $targetItem into our function
        // ====================================================================
        function toGalleryItem($targetItem){
            // Make sure the target item exists, otherwise do nothing
            if($targetItem){
                // The new position is just to the left of the targetItem - returns the x-coordinate relative to the element's first offset parent
                var newPosition = $targetItem.position().left;

                // If the new position isn't greater than the maximum width
                if(newPosition <= maxScrollPosition){

                    // Add active class to the target item
                    $targetItem.addClass("gallery_item--active");

                    // Remove the Active class from all other items
                    $targetItem.siblings().removeClass("gallery_item--active");

                    // Animate .gallery element to the correct left position.
                    $(".gallery").animate({

                        left : - newPosition
                    }, "fast");              
                }
            }
        }

        // Basic HTML manipulation
        // ====================================================================
        // Set the gallery width to the totalWidth. This allows all items to
        // be on one line.
        $(".gallery").outerWidth(totalWidth);

        // Add active class to the first gallery item
        $("span:first").addClass("gallery_item--active");

        // When the prev button is clicked
        // ====================================================================
        $(".gallery_controls-prev").click(function(){
            // Set target item to the item before the active item
            var target = $(".gallery_item--active").prev();
            toGalleryItem(target);
        });

        // When the next button is clicked
        // ====================================================================
        $(".gallery_controls-next").click(function(){
            // Set target item to the item after the active item
            var target = $(".gallery_item--active").next();
            toGalleryItem(target);
        });

    }

}(jQuery));

	
